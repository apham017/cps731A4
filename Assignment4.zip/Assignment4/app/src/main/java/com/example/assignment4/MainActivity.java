package com.example.assignment4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    String s1[],s2[],s3[];
    int images[] = {R.drawable.ssjgoku, R.drawable.freiza, R.drawable.android16, R.drawable.jiren, R.drawable.roshi, R.drawable.bardock};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerview);

        s1 = getResources().getStringArray(R.array.fgarchetypes);
        s2 = getResources().getStringArray(R.array.description);
        s3=getResources().getStringArray(R.array.detaileddesc);
        fgadapter fgadapter = new fgadapter(this, s1,s2,images, s3);
        recyclerView.setAdapter(fgadapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}