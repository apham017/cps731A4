package com.example.assignment4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Act1 extends AppCompatActivity {
    ImageView act1img;
    TextView act1tit, act1desc;
    String d1, d3;
    int img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act1);

        act1img = findViewById(R.id.allrounder);
        act1tit = findViewById(R.id.artit);
        act1desc = findViewById(R.id.ardesc);
        getData();
        setData();

    }

    private void getData() {
        if (getIntent().hasExtra("d1") && getIntent().hasExtra("d3")) {
            d1 = getIntent().getStringExtra("d1");
            d3 = getIntent().getStringExtra("d3");
            img = getIntent().getIntExtra("images",1);

        } else {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }
        private void setData() {
            act1tit.setText(d1);
            act1desc.setText(d3);
            act1img.setImageResource(img);
    }
}